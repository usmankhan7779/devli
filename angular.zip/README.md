Angular 7 Project for Lineups.com

Please reference the wiki for instructions on workflow, universal styles, etc. 
