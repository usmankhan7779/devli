import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nba-lineups-module',
  template: `<router-outlet></router-outlet>`
})
export class LineupsGatewayModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
