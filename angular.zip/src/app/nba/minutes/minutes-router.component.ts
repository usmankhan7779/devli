import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-minutes-router',
  template: `<router-outlet></router-outlet>`
})
export class MinutesRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
