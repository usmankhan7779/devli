import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nba-single-player',
  template: `<router-outlet></router-outlet>`
})
export class NbaSinglePlayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
