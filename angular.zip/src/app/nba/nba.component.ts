import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nba',
  templateUrl: './nba.component.html'
})
export class NbaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
