import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-stats-offense-defense-module',
  template: `<router-outlet></router-outlet>`
})
export class TeamStatsOffenseDefenseModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
