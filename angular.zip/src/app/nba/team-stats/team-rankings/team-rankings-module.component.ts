import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nba-team-rankings-module',
  template: `<router-outlet></router-outlet>`
})
export class TeamRankingsModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
