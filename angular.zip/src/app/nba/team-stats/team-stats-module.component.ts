import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nba-team-stats-module',
  template: `<router-outlet></router-outlet>`
})
export class TeamStatsModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
