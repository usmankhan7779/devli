import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-college-football',
  templateUrl: './college-football.component.html',
})
export class CollegeFootballComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
