import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mlb-dp',
  template: `<router-outlet></router-outlet>`
})
export class DepthChartsModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
