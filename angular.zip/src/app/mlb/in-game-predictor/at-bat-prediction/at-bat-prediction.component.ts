import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-at-bat-prediction',
  templateUrl: './at-bat-prediction.component.html',
  styleUrls: ['./at-bat-prediction.component.scss']
})
export class AtBatPredictionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
