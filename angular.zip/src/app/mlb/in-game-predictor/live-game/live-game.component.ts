import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-game',
  templateUrl: './live-game.component.html',
  styleUrls: ['./live-game.component.scss']
})
export class LiveGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
