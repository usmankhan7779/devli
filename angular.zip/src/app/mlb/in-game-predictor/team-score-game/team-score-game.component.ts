import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-score-game',
  templateUrl: './team-score-game.component.html',
  styleUrls: ['./team-score-game.component.scss']
})
export class TeamScoreGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
