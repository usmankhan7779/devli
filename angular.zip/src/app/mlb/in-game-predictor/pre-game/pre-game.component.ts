import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-game',
  templateUrl: './pre-game.component.html',
  styleUrls: ['./pre-game.component.scss']
})
export class PreGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
