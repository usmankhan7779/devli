import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-park-factor-tools',
  template: `<router-outlet></router-outlet>`
})
export class ParkFactorToolsModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
