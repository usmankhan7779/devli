import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mlb',
  templateUrl: './mlb.component.html',
  styleUrls: ['./mlb.component.scss']
})
export class MlbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
