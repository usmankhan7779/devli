import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fantasy-baseball-projections-route',
  template: `<router-outlet></router-outlet>`
})
export class FantasyBaseballProjectionsRouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
